'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { addPick, Pick } from '@/lib/api';
import { Button, Input, Select, Textarea, PageHeader, Card } from '@/components/ui';

const LEAGUES = [
  'Premier League',
  'Eliteserien',
  'La Liga',
  'Bundesliga',
  'Serie A',
  'Ligue 1',
  'Champions League',
  'Europa League',
  'Conference League',
  'Championship',
  'Eredivisie',
  'Annet',
];

const TIERS = ['A', 'B', 'C'];

interface FormData {
  league: string;
  home_team: string;
  away_team: string;
  pick: string;
  odds: string;
  stake: string;
  ev_percent: string;
  tier: string;
  comment: string;
}

interface FormErrors {
  [key: string]: string;
}

export default function AddPickPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [form, setForm] = useState<FormData>({
    league: 'Premier League',
    home_team: '',
    away_team: '',
    pick: '',
    odds: '',
    stake: '',
    ev_percent: '',
    tier: 'A',
    comment: '',
  });

  const [errors, setErrors] = useState<FormErrors>({});

  const update = (field: keyof FormData, value: string) => {
    setForm(prev => ({ ...prev, [field]: value }));
    if (errors[field]) setErrors(prev => ({ ...prev, [field]: '' }));
  };

  const validate = (): boolean => {
    const newErrors: FormErrors = {};
    if (!form.home_team.trim()) newErrors.home_team = 'Påkrevd';
    if (!form.away_team.trim()) newErrors.away_team = 'Påkrevd';
    if (!form.pick.trim()) newErrors.pick = 'Påkrevd';
    if (!form.odds || isNaN(Number(form.odds)) || Number(form.odds) < 1) {
      newErrors.odds = 'Ugyldig odds (min 1.00)';
    }
    if (!form.stake || isNaN(Number(form.stake)) || Number(form.stake) <= 0) {
      newErrors.stake = 'Ugyldig stake';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    try {
      setLoading(true);
      setError(null);
      const payload: Omit<Pick, 'id' | 'created_at'> = {
        league: form.league,
        home_team: form.home_team.trim(),
        away_team: form.away_team.trim(),
        match: `${form.home_team.trim()} vs ${form.away_team.trim()}`,
        pick: form.pick.trim(),
        odds: Number(form.odds),
        stake: Number(form.stake),
        ev_percent: form.ev_percent ? Number(form.ev_percent) : undefined,
        tier: form.tier,
        comment: form.comment.trim() || undefined,
      };
      await addPick(payload);
      setSuccess(true);
      setTimeout(() => {
        router.push('/history');
      }, 1500);
    } catch {
      setError('Kunne ikke lagre pick. Prøv igjen.');
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setForm({
      league: 'Premier League',
      home_team: '',
      away_team: '',
      pick: '',
      odds: '',
      stake: '',
      ev_percent: '',
      tier: 'A',
      comment: '',
    });
    setErrors({});
    setError(null);
    setSuccess(false);
  };

  if (success) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4 px-6">
        <div className="w-16 h-16 rounded-full bg-green-500/10 flex items-center justify-center">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#22c55e" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M20 6L9 17l-5-5" />
          </svg>
        </div>
        <h2 className="text-xl font-bold text-slate-100">Pick lagret!</h2>
        <p className="text-sm text-slate-500 text-center">Sender deg til historikk...</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-full">
      <PageHeader title="Legg til Pick" subtitle="Registrer ny satsing" />

      <div className="px-4 pb-6">
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          {/* League */}
          <Select
            label="Liga"
            value={form.league}
            onChange={e => update('league', e.target.value)}
          >
            {LEAGUES.map(l => (
              <option key={l} value={l}>{l}</option>
            ))}
          </Select>

          {/* Teams */}
          <div className="grid grid-cols-2 gap-3">
            <Input
              label="Hjemmelag"
              placeholder="Arsenal"
              value={form.home_team}
              onChange={e => update('home_team', e.target.value)}
              error={errors.home_team}
            />
            <Input
              label="Bortelag"
              placeholder="Chelsea"
              value={form.away_team}
              onChange={e => update('away_team', e.target.value)}
              error={errors.away_team}
            />
          </div>

          {/* Pick */}
          <Input
            label="Pick"
            placeholder="Over 2.5, Arsenal ML, 1X..."
            value={form.pick}
            onChange={e => update('pick', e.target.value)}
            error={errors.pick}
          />

          {/* Odds & Stake */}
          <div className="grid grid-cols-2 gap-3">
            <Input
              label="Odds"
              type="number"
              step="0.01"
              min="1"
              placeholder="2.10"
              value={form.odds}
              onChange={e => update('odds', e.target.value)}
              error={errors.odds}
            />
            <Input
              label="Stake (u)"
              type="number"
              step="0.5"
              min="0"
              placeholder="2.0"
              value={form.stake}
              onChange={e => update('stake', e.target.value)}
              error={errors.stake}
            />
          </div>

          {/* EV% & Tier */}
          <div className="grid grid-cols-2 gap-3">
            <Input
              label="EV% (valgfritt)"
              type="number"
              step="0.1"
              placeholder="5.2"
              value={form.ev_percent}
              onChange={e => update('ev_percent', e.target.value)}
            />
            <Select
              label="Tier"
              value={form.tier}
              onChange={e => update('tier', e.target.value)}
            >
              {TIERS.map(t => (
                <option key={t} value={t}>Tier {t}</option>
              ))}
            </Select>
          </div>

          {/* Comment */}
          <Textarea
            label="Kommentar (valgfritt)"
            placeholder="Kort begrunnelse for satsen..."
            value={form.comment}
            onChange={e => update('comment', e.target.value)}
            rows={3}
          />

          {/* Error */}
          {error && (
            <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-3">
              <p className="text-sm text-red-400">{error}</p>
            </div>
          )}

          {/* Preview */}
          {form.home_team && form.away_team && form.pick && form.odds && (
            <Card className="bg-slate-800/50">
              <p className="text-xs text-slate-500 uppercase tracking-widest mb-2">Forhåndsvisning</p>
              <p className="text-sm font-semibold text-slate-100">{form.home_team} vs {form.away_team}</p>
              <p className="text-xs text-slate-400 mt-0.5">{form.pick} @ {form.odds}</p>
              <div className="flex gap-3 mt-2">
                {form.stake && <span className="text-xs text-amber-400">{form.stake}u stake</span>}
                {form.ev_percent && <span className="text-xs text-green-400">EV: +{form.ev_percent}%</span>}
                {form.tier && <span className="text-xs text-blue-400">Tier {form.tier}</span>}
              </div>
            </Card>
          )}

          {/* Actions */}
          <div className="flex gap-3">
            <Button
              type="button"
              variant="ghost"
              size="md"
              className="flex-1"
              onClick={handleReset}
            >
              Nullstill
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="md"
              className="flex-2 flex-grow"
              loading={loading}
            >
              {loading ? 'Lagrer...' : 'Lagre pick'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
