'use client';

import { useState, useEffect, useCallback } from 'react';
import { getStats, StatsData } from '@/lib/api';
import { formatPercent } from '@/lib/utils';
import { Card, Spinner, ErrorState, StatCard, PageHeader } from '@/components/ui';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell,
  LineChart, Line, CartesianGrid,
} from 'recharts';

export default function StatsPage() {
  const [stats, setStats] = useState<StatsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
      setError(null);
      setLoading(true);
      const data = await getStats();
      setStats(data);
    } catch {
      setError('Kunne ikke hente statistikk.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return (
    <div className="flex flex-col min-h-full">
      <PageHeader title="Statistikk" subtitle="Ytelse og analyse" />

      <div className="px-4 pb-6 flex flex-col gap-4">
        {loading && (
          <div className="flex items-center justify-center py-16">
            <Spinner size="lg" className="text-amber-400" />
          </div>
        )}

        {!loading && error && <ErrorState message={error} onRetry={fetchData} />}

        {!loading && !error && stats && (
          <>
            {/* Top KPIs */}
            <div className="grid grid-cols-2 gap-3">
              <StatCard
                label="Total ROI"
                value={formatPercent(stats.total_roi)}
                valueClass={stats.total_roi !== undefined && stats.total_roi >= 0 ? 'text-green-400 glow-green' : 'text-red-400'}
              />
              <StatCard
                label="Win Rate"
                value={`${(stats.win_rate || 0).toFixed(1)}%`}
                sub={`${stats.wins}W / ${stats.losses}L / ${stats.pushes}P`}
                valueClass="text-blue-400"
              />
              <StatCard
                label="Total Picks"
                value={stats.total_picks || 0}
                valueClass="text-slate-100"
              />
              <StatCard
                label="Profit 30d"
                value={`${(stats.profit_30d || 0) >= 0 ? '+' : ''}${(stats.profit_30d || 0).toFixed(1)}u`}
                valueClass={(stats.profit_30d || 0) >= 0 ? 'text-green-400' : 'text-red-400'}
              />
            </div>

            {/* Secondary KPIs */}
            <div className="grid grid-cols-3 gap-3">
              <MiniStatCard label="Avg Odds" value={(stats.avg_odds || 0).toFixed(2)} />
              <MiniStatCard
                label="Avg EV%"
                value={`${(stats.avg_ev || 0) >= 0 ? '+' : ''}${(stats.avg_ev || 0).toFixed(1)}%`}
                valueClass={(stats.avg_ev || 0) >= 0 ? 'text-green-400' : 'text-red-400'}
              />
              <MiniStatCard
                label="Avg CLV"
                value={`${(stats.avg_clv || 0) >= 0 ? '+' : ''}${(stats.avg_clv || 0).toFixed(2)}`}
                valueClass={(stats.avg_clv || 0) >= 0 ? 'text-green-400' : 'text-red-400'}
              />
            </div>

            {/* Win/Loss/Push Breakdown */}
            <Card>
              <p className="text-xs text-slate-500 uppercase tracking-widest mb-3">Resultatfordeling</p>
              <WinLossBar wins={stats.wins || 0} losses={stats.losses || 0} pushes={stats.pushes || 0} />
            </Card>

            {/* CLV History Chart */}
            {stats.clv_history && stats.clv_history.length > 0 && (
              <Card>
                <p className="text-xs text-slate-500 uppercase tracking-widest mb-3">CLV Historikk</p>
                <ResponsiveContainer width="100%" height={120}>
                  <LineChart data={stats.clv_history} margin={{ top: 4, right: 4, bottom: 0, left: -20 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis dataKey="date" tick={{ fill: '#64748b', fontSize: 9 }} tickLine={false} axisLine={false} />
                    <YAxis tick={{ fill: '#64748b', fontSize: 9 }} tickLine={false} axisLine={false} />
                    <Tooltip
                      contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 8, fontSize: 11 }}
                      labelStyle={{ color: '#94a3b8' }}
                      itemStyle={{ color: '#3b82f6' }}
                    />
                    <Line type="monotone" dataKey="clv" stroke="#3b82f6" strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </Card>
            )}

            {/* Best Leagues */}
            {stats.by_league && stats.by_league.length > 0 && (
              <Card>
                <p className="text-xs text-slate-500 uppercase tracking-widest mb-3">ROI per Liga</p>
                <ResponsiveContainer width="100%" height={Math.max(100, stats.by_league.length * 32)}>
                  <BarChart
                    data={stats.by_league.slice(0, 8)}
                    layout="vertical"
                    margin={{ top: 0, right: 40, bottom: 0, left: 0 }}
                  >
                    <XAxis type="number" tick={{ fill: '#64748b', fontSize: 9 }} tickLine={false} axisLine={false} tickFormatter={v => `${v}%`} />
                    <YAxis
                      type="category"
                      dataKey="league"
                      tick={{ fill: '#94a3b8', fontSize: 10 }}
                      tickLine={false}
                      axisLine={false}
                      width={100}
                    />
                    <Tooltip
                      contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 8, fontSize: 11 }}
                      labelStyle={{ color: '#94a3b8' }}
                      formatter={(value, _name, props) => [
                        `${typeof value === 'number' ? value.toFixed(1) : value}% (${(props as { payload?: { picks?: number } }).payload?.picks || 0} picks)`,
                        'ROI',
                      ]}
                    />
                    <Bar dataKey="roi" radius={[0, 4, 4, 0]}>
                      {stats.by_league.slice(0, 8).map((entry, index) => (
                        <Cell key={index} fill={entry.roi >= 0 ? '#22c55e' : '#ef4444'} opacity={0.8} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </Card>
            )}

            {/* Empty state */}
            {(stats.total_picks || 0) === 0 && (
              <div className="text-center py-8">
                <p className="text-slate-500 text-sm">Ingen picks ennå. Legg til picks for å se statistikk.</p>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

function MiniStatCard({ label, value, valueClass = 'text-slate-100' }: { label: string; value: string; valueClass?: string }) {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 flex flex-col gap-1">
      <span className="text-[9px] text-slate-500 uppercase tracking-widest">{label}</span>
      <span className={`text-base font-bold tabular-nums ${valueClass}`}>{value}</span>
    </div>
  );
}

function WinLossBar({ wins, losses, pushes }: { wins: number; losses: number; pushes: number }) {
  const total = wins + losses + pushes;
  if (total === 0) {
    return <p className="text-sm text-slate-500 text-center py-2">Ingen resultater ennå</p>;
  }
  const wPct = (wins / total) * 100;
  const lPct = (losses / total) * 100;
  const pPct = (pushes / total) * 100;

  return (
    <div className="flex flex-col gap-3">
      <div className="flex h-3 rounded-full overflow-hidden gap-0.5">
        {wPct > 0 && <div className="bg-green-500 rounded-l-full" style={{ width: `${wPct}%` }} />}
        {lPct > 0 && <div className="bg-red-500" style={{ width: `${lPct}%` }} />}
        {pPct > 0 && <div className="bg-amber-500 rounded-r-full" style={{ width: `${pPct}%` }} />}
      </div>
      <div className="flex justify-between text-xs">
        <span className="text-green-400 font-semibold">{wins}W ({wPct.toFixed(0)}%)</span>
        <span className="text-amber-400 font-semibold">{pushes}P ({pPct.toFixed(0)}%)</span>
        <span className="text-red-400 font-semibold">{losses}L ({lPct.toFixed(0)}%)</span>
      </div>
    </div>
  );
}
