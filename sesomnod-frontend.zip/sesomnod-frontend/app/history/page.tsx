'use client';

import { useState, useEffect, useCallback, useMemo } from 'react';
import { getPicks, getBankroll, Pick, BankrollEntry } from '@/lib/api';
import { formatDate, formatOdds, formatCurrency, resultBadge, tierColor } from '@/lib/utils';
import { Card, Badge, Button, Spinner, ErrorState, EmptyState, PageHeader, StatCard } from '@/components/ui';
import EquityCurve from '@/components/charts/EquityCurve';
import Link from 'next/link';

const LEAGUES = ['Alle', 'Premier League', 'Eliteserien', 'La Liga', 'Bundesliga', 'Serie A', 'Champions League'];
const RESULTS = ['Alle', 'W', 'L', 'P', 'Pending'];

export default function HistoryPage() {
  const [picks, setPicks] = useState<Pick[]>([]);
  const [bankroll, setBankroll] = useState<BankrollEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filterLeague, setFilterLeague] = useState('Alle');
  const [filterResult, setFilterResult] = useState('Alle');
  const [search, setSearch] = useState('');

  const fetchData = useCallback(async () => {
    try {
      setError(null);
      setLoading(true);
      const [picksRes, bankrollRes] = await Promise.all([getPicks(), getBankroll()]);
      setPicks(picksRes.data || []);
      setBankroll(bankrollRes.data || []);
    } catch {
      setError('Kunne ikke hente historikk. Sjekk tilkobling.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const filtered = useMemo(() => {
    return picks.filter((p) => {
      if (filterLeague !== 'Alle' && p.league !== filterLeague) return false;
      if (filterResult !== 'Alle') {
        if (filterResult === 'Pending' && p.result) return false;
        if (filterResult !== 'Pending' && p.result !== filterResult) return false;
      }
      if (search) {
        const q = search.toLowerCase();
        return (
          (p.match || '').toLowerCase().includes(q) ||
          (p.pick || '').toLowerCase().includes(q) ||
          (p.league || '').toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [picks, filterLeague, filterResult, search]);

  const currentBalance = bankroll.length > 0
    ? bankroll[bankroll.length - 1]?.balance
    : picks.reduce((sum, p) => sum + (p.profit || 0), 1000);

  const totalProfit = picks.reduce((sum, p) => sum + (p.profit || 0), 0);
  const wins = picks.filter(p => p.result === 'W').length;
  const settled = picks.filter(p => p.result === 'W' || p.result === 'L').length;
  const winRate = settled > 0 ? (wins / settled) * 100 : 0;

  return (
    <div className="flex flex-col min-h-full">
      <PageHeader title="History" subtitle="Alle picks og bankroll-utvikling" />

      <div className="px-4 pb-6 flex flex-col gap-4">
        {loading && (
          <div className="flex items-center justify-center py-16">
            <Spinner size="lg" className="text-amber-400" />
          </div>
        )}

        {!loading && error && <ErrorState message={error} onRetry={fetchData} />}

        {!loading && !error && (
          <>
            {/* Summary Stats */}
            <div className="grid grid-cols-3 gap-3">
              <StatCard
                label="Bankroll"
                value={`${(currentBalance || 0).toFixed(0)}u`}
                valueClass="text-amber-400"
              />
              <StatCard
                label="Profit"
                value={`${totalProfit >= 0 ? '+' : ''}${totalProfit.toFixed(1)}u`}
                valueClass={totalProfit >= 0 ? 'text-green-400' : 'text-red-400'}
              />
              <StatCard
                label="Win Rate"
                value={`${winRate.toFixed(0)}%`}
                sub={`${wins}/${settled}`}
                valueClass="text-blue-400"
              />
            </div>

            {/* Equity Curve */}
            <Card>
              <EquityCurve bankroll={bankroll} picks={picks} />
            </Card>

            {/* Filters */}
            <div className="flex flex-col gap-2">
              <input
                type="text"
                placeholder="Søk kamp, pick, liga..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2.5 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-500/50"
              />
              <div className="flex gap-2 overflow-x-auto pb-1">
                {RESULTS.map(r => (
                  <button
                    key={r}
                    onClick={() => setFilterResult(r)}
                    className={`flex-shrink-0 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                      filterResult === r
                        ? 'bg-amber-500 text-slate-950'
                        : 'bg-slate-800 text-slate-400 border border-slate-700'
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>
              <div className="flex gap-2 overflow-x-auto pb-1">
                {LEAGUES.map(l => (
                  <button
                    key={l}
                    onClick={() => setFilterLeague(l)}
                    className={`flex-shrink-0 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                      filterLeague === l
                        ? 'bg-blue-500 text-white'
                        : 'bg-slate-800 text-slate-400 border border-slate-700'
                    }`}
                  >
                    {l}
                  </button>
                ))}
              </div>
            </div>

            {/* Add Pick CTA */}
            <Link href="/add-pick">
              <Button variant="secondary" size="md" className="w-full">
                + Legg til pick
              </Button>
            </Link>

            {/* Picks count */}
            <p className="text-xs text-slate-500 px-1">
              Viser {filtered.length} av {picks.length} picks
            </p>

            {/* Picks List */}
            {filtered.length === 0 ? (
              <EmptyState
                message="Ingen picks matcher filteret."
                icon={
                  <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                    <path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                }
              />
            ) : (
              <div className="flex flex-col gap-2">
                {filtered.map((pick, i) => (
                  <PickRow key={pick.id || i} pick={pick} />
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

function PickRow({ pick }: { pick: Pick }) {
  const [expanded, setExpanded] = useState(false);

  return (
    <button
      onClick={() => setExpanded(!expanded)}
      className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-left active:bg-slate-800 transition-colors w-full"
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 mb-1">
            <span className="text-[10px] text-slate-500">{formatDate(pick.created_at)}</span>
            {pick.tier && (
              <Badge className={`${tierColor(pick.tier)} text-[9px]`}>{pick.tier}</Badge>
            )}
            {pick.league && (
              <span className="text-[10px] text-slate-500 truncate">{pick.league}</span>
            )}
          </div>
          <p className="text-sm font-semibold text-slate-100 truncate">
            {pick.match || `${pick.home_team || ''} vs ${pick.away_team || ''}`}
          </p>
          <p className="text-xs text-slate-400 mt-0.5">{pick.pick || '—'}</p>
        </div>
        <div className="flex flex-col items-end gap-1 flex-shrink-0">
          <Badge className={resultBadge(pick.result)}>
            {pick.result || 'Pending'}
          </Badge>
          <span className={`text-sm font-bold tabular-nums ${pick.profit !== undefined ? (pick.profit >= 0 ? 'text-green-400' : 'text-red-400') : 'text-slate-400'}`}>
            {pick.profit !== undefined ? formatCurrency(pick.profit) : '—'}
          </span>
        </div>
      </div>

      {expanded && (
        <div className="mt-3 pt-3 border-t border-slate-800 grid grid-cols-3 gap-2">
          <MiniStat label="Odds" value={formatOdds(pick.odds)} />
          <MiniStat label="Stake" value={pick.stake !== undefined ? `${pick.stake}u` : '—'} />
          <MiniStat
            label="EV%"
            value={pick.ev_percent !== undefined ? `${pick.ev_percent > 0 ? '+' : ''}${pick.ev_percent?.toFixed(1)}%` : '—'}
            valueClass={pick.ev_percent !== undefined ? (pick.ev_percent > 0 ? 'text-green-400' : 'text-red-400') : 'text-slate-400'}
          />
          {pick.clv !== undefined && (
            <MiniStat label="CLV" value={`${pick.clv > 0 ? '+' : ''}${pick.clv?.toFixed(2)}`} valueClass="text-blue-400" />
          )}
          {pick.comment && (
            <div className="col-span-3 mt-1">
              <p className="text-xs text-slate-500 leading-relaxed">{pick.comment}</p>
            </div>
          )}
        </div>
      )}
    </button>
  );
}

function MiniStat({ label, value, valueClass = 'text-slate-300' }: { label: string; value: string; valueClass?: string }) {
  return (
    <div className="flex flex-col gap-0.5">
      <span className="text-[9px] text-slate-600 uppercase tracking-widest">{label}</span>
      <span className={`text-xs font-semibold tabular-nums ${valueClass}`}>{value}</span>
    </div>
  );
}
